// ARPDlg.h : header file
//

#if !defined(AFX_ARPDLG_H__72B28558_B02D_459C_A740_3992C742B656__INCLUDED_)
#define AFX_ARPDLG_H__72B28558_B02D_459C_A740_3992C742B656__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "DataStructure.h"
/////////////////////////////////////////////////////////////////////////////
// CARPDlg dialog

class CARPDlg : public CDialog
{
// Construction
public:
	CARPDlg(CWnd* pParent = NULL);	// standard constructor
public:
	//����
	void FindAllDevs();
	void CatchPackets();
	void CapturePkt();	//�������

	//����
	pcap_if_t* alldevs;	//pcap_if_t : �ӿ��б��е�һ���pcap_findalldevs()��ʹ��
	pcap_if_t* d;		//����ѭ��
	pcap_t* adhandle;	//����ѭ���е�����һ�����д���
	char errbuf[PCAP_ERRBUF_SIZE];	//������Ϣ
	u_int netmask;
	char packet_filter[20];			//ѡ��������ͣ�arpЭ�飩
	struct bpf_program fcode;

// Dialog Data
	//{{AFX_DATA(CARPDlg)
	enum { IDD = IDD_ARP_DIALOG };
	CComboBox	m_cobListDev;
	CListCtrl	m_listPackets;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CARPDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CARPDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButtonCatch();
	afx_msg void OnButtonStopcatch();
	afx_msg void OnSelchangeComboNetcard();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ARPDLG_H__72B28558_B02D_459C_A740_3992C742B656__INCLUDED_)
