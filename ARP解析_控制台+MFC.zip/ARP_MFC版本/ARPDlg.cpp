// ARPDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ARP.h"
#include "ARPDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CARPDlg dialog

CARPDlg::CARPDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CARPDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CARPDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CARPDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CARPDlg)
	DDX_Control(pDX, IDC_COMBO_NETCARD, m_cobListDev);
	DDX_Control(pDX, IDC_LIST_PACKETS, m_listPackets);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CARPDlg, CDialog)
	//{{AFX_MSG_MAP(CARPDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_CATCH, OnButtonCatch)
	ON_BN_CLICKED(IDC_BUTTON_STOPCATCH, OnButtonStopcatch)
	ON_CBN_SELCHANGE(IDC_COMBO_NETCARD, OnSelchangeComboNetcard)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CARPDlg message handlers

BOOL CARPDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	/*��ʼ��һЩ�ṹ*/
	m_listPackets.InsertColumn(0,"���",LVCFMT_CENTER,50,0);
	m_listPackets.InsertColumn(1,"ʱ��",LVCFMT_CENTER,80,1);
	m_listPackets.InsertColumn(2,"Ŀ��MAC��ַ",LVCFMT_CENTER,200,2);
	m_listPackets.InsertColumn(3,"ԴMAC��ַ",LVCFMT_CENTER,200,3);
	m_listPackets.InsertColumn(4,"����",LVCFMT_CENTER,50,4);
	m_listPackets.InsertColumn(5,"�ϲ�Э��",LVCFMT_CENTER,100,5);

	/*����һЩ��ť*/
	GetDlgItem(IDC_BUTTON_CATCH)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_STOPCATCH)->EnableWindow(FALSE);

	/*���Ȼ�ȡ���ػ����豸�б�����ʾ���û�*/
	FindAllDevs();
	string strFilter = "arp";	
	strcpy(packet_filter,strFilter.c_str());//��Ĭ��ץȡarp
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CARPDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CARPDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CARPDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

//��ʼץ����ť
void CARPDlg::OnButtonCatch() 
{
	// TODO: Add your control notification handler code here
	CatchPackets();
}

//ֹͣץ����ť
void CARPDlg::OnButtonStopcatch() 
{
	// TODO: Add your control notification handler code here
	
}

/*��ȡ���ػ����豸�б�*/
void CARPDlg::FindAllDevs()
{
	int i = 0;
	if (pcap_findalldevs_ex(PCAP_SRC_IF_STRING,NULL/*����Ҫ��֤*/,&alldevs, errbuf) == -1) 
	{
		fprintf(stderr, "Error in pcap_findalldevs_ex�������豸�б�����: %s\n", errbuf);
	}

	/* ��ӡ�б� */
	for (d = alldevs; d != NULL; d = d->next)
	{
		m_cobListDev.InsertString(i,_T(d->name));
		i++;
	}

	if (0 == i)
		AfxMessageBox(_T("û���ҵ��豸�б���"),MB_OK|MB_ICONSTOP);
}

//ѡ��������Ĳ���
void CARPDlg::OnSelchangeComboNetcard() 
{
	// TODO: Add your control notification handler code here
	int nIndex = m_cobListDev.GetCurSel();
	int i = 0;
	//��ת����Ӧ������
	for (d = alldevs; i < nIndex; d = d->next, i++);

	GetDlgItem(IDC_BUTTON_CATCH)->EnableWindow(TRUE);
	
}

void CARPDlg::CatchPackets()
{
	/* ���豸 */
	if ( (adhandle = pcap_open(d->name,	//�豸��
		65536,							//�������ݰ�
		PCAP_OPENFLAG_PROMISCUOUS,		//����ģʽ
		1000,							//��ȡ��ʱʱ��
		NULL,							//Զ�̼�����֤
		errbuf							//���󻺳��
		)) == NULL)
	{

		fprintf(stderr, "\n���ܴ�������.%s WinPcap��֧�ָ���������\n", errbuf);
		AfxMessageBox(_T("���ܴ򿪸���������WinPcap��֧�ָ���������"),MB_OK|MB_ICONSTOP);
		pcap_freealldevs(alldevs);//�ͷ��豸�б�
		return;
	}

	/* ���������·�㣬������ֻ������̫�� */
	if (pcap_datalink(adhandle) != DLT_EN10MB && d->addresses == NULL)
	{
		//�ж��������ͣ���λ����֡����������װ��packet
		//DLT_IEEE802��ʾ���ƻ���
		AfxMessageBox(_T("������ֻ��������̫����."),MB_OK|MB_ICONSTOP);
		pcap_freealldevs(alldevs);
		return;
	}

	if(d->addresses != NULL)
	{	/* ��ýӿڵĵ�һ����ַ������ */
		netmask = ((struct sockaddr_in*)(d->addresses->netmask))->sin_addr.S_un.S_addr;
	}
	else	
	{//����ӿ�û�е�ַ�����Ǽ�������C�������� 
		netmask = 0xffffff;
	}

/////////////////////////////
	
	//���������
	if (pcap_compile(adhandle, &fcode, packet_filter, 1, netmask)< 0)
	{
		fprintf(stderr, "\nUnable to compile the packet filter.Check the syntax\n");
		AfxMessageBox(_T("�޷����ù�����."),MB_OK|MB_ICONSTOP);
		pcap_freealldevs(alldevs);
		return;
	}

	//���ù�����
	if(pcap_setfilter(adhandle, &fcode)<0)
	 {
		 fprintf(stderr, "\nError setting the filter.\n");
		 pcap_freealldevs(alldevs);
		 AfxMessageBox(_T("װ�ع�����ʧ��"),MB_OK|MB_ICONSTOP);
		 return;
	 }

/////////////////////////////
	CString mes = "��ʼ����";
	MessageBox(mes);
	pcap_freealldevs(alldevs);//�ͷ�

	int packet_num = 10;//Ĭ��ץȡ2�������֮��������û�����
	//m_iPktNum = 0;//��ʼ��0
	
	//pcap_loop(adhandle, packet_num, ethernet_packet_loop,NULL);
	for(int i = 0;i<packet_num;i++)
	{
		CapturePkt();
	}

	GetDlgItem(IDC_BUTTON_CATCH)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_STOPCATCH)->EnableWindow(TRUE);
	//////////////////////////////////////

}

//������
void CARPDlg::CapturePkt()
{
	int nCout = m_listPackets.GetItemCount();//�Ȼ�ȡ��ǰ����
	CString strNo;//���
	pcap_pkthdr* pkt_header;
	const u_char* pkt_data;
	struct ethernet *ether_data;
	CString info1,info2,info3,info4,info5;	//���pkt_data����������
	struct tm *ltime;
	int res;
	
	if((res = pcap_next_ex(adhandle,&pkt_header,&pkt_data))>0)//�������ݰ�
	{
		//m_iPktNum ++;
		if(pkt_header->caplen<14)
			return;	
		
		strNo.Format("%d",nCout+1);//���
		int nItem = m_listPackets.InsertItem(nCout,strNo);

		ether_data = (struct ethernet*)pkt_data;//������̫��֡

		//ʱ��
		ltime = localtime(&(pkt_header->ts.tv_sec));
		info1.Format("%02d: %02d: %02d",ltime->tm_hour,ltime->tm_min,ltime->tm_sec);
		m_listPackets.SetItemText(nItem,1,info1);


		u_short eth_type = ntohs(ether_data->ether_type);
		u_char *macstring1 = ether_data->ether_src;
		u_char *macstring2 = ether_data->ether_dst;	
		//��ַ
		CString dst_addr,src_addr;
		CString dst,src;//�����ַ�ת��
		for(int i = 0;i<6;i++)
		{
			dst.Format(_T("%x"),int(*macstring2 + i));
			dst_addr += dst;
			dst_addr += ":";
			src.Format(_T("%x"),int(*macstring1 + i));
			src_addr += src;
			src_addr += ":";
		}
		m_listPackets.SetItemText(nItem,2,dst_addr);
		m_listPackets.SetItemText(nItem,3,src_addr);
	
		//����
		info3.Format(_T("%4d"),pkt_header->caplen);
		m_listPackets.SetItemText(nItem,4,info3);

		//��̫��Э��
		switch (eth_type)
		{
		case 0x0800: 
			info2 = " IPЭ�� " ; 
			break;
		case 0x0806: 
			info2 = " ARPЭ�� ";
			//analyze_arp(pkt_header,pkt_data);
			break;
		case 0x86dd: 
			info2 = " ICMPЭ��" ; 
			break;
		default:break;
		}
		m_listPackets.SetItemText(nItem,5,info2);
	
	}

}