//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by FtpClient.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_FTPCLIENT_DIALOG            102
#define IDR_MAINFRAME                   128
#define IDD_DIALOG_RENAME               129
#define IDC_EDIT_SERVERNAME             1000
#define IDC_EDIT_USERNAME               1001
#define IDC_EDIT_PASSWORD               1002
#define IDC_LIST_DIRECTORY              1003
#define IDC_BUTTON_LOGIN                1004
#define IDC_BUTTON_LOGOUT               1005
#define IDC_EDIT_NEWNAME                1005
#define IDC_BUTTON_PARENTDIR            1006
#define IDC_BUTTON_SUBDIR               1007
#define IDC_BUTTON_UPLOAD               1009
#define IDC_BUTTON_DOWNLOAD             1010
#define IDC_BUTTON_QUERY                1011
#define IDC_BUTTON_DELETE               1012
#define IDC_BUTTON_RENAME               1013

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
