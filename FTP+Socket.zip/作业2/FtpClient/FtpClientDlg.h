// FtpClientDlg.h : header file
//

#if !defined(AFX_FTPCLIENTDLG_H__2EE974A7_C302_45C3_82FB_0AEE4ACA0081__INCLUDED_)
#define AFX_FTPCLIENTDLG_H__2EE974A7_C302_45C3_82FB_0AEE4ACA0081__INCLUDED_
#include <afxinet.h>
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CFtpClientDlg dialog

class CFtpClientDlg : public CDialog
{
// Construction
public:

	bool Connect(CString serverName,CString userName,CString password);
	void DisplayParentDir();
	CString GetParentDirectory(CString str);
	void DisplaySubDir();
	void DeleteFile();
	void Rename();
	void Upload();
	void Download();
	void DisplayContent(LPCTSTR lpctstr,CString currentDir = _T("/"));
	CFtpClientDlg(CWnd* pParent = NULL);	// standard constructor

public:
	CFtpFileFind* m_pFileFind;		//�����ļ����������ļ�
	CInternetSession* m_pFTPSession;//���ڽ������������ĻỰ����
	CFtpConnection* m_pConnection;	//�������õ�ǰĿ¼�ʹ��ļ�
// Dialog Data
	//{{AFX_DATA(CFtpClientDlg)
	enum { IDD = IDD_FTPCLIENT_DIALOG };
	CListCtrl	m_listDirectory;
	CString	m_strServerName;
	CString	m_strUserName;
	CString	m_strPassword;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFtpClientDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CFtpClientDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnClickedButtonLogin();
	afx_msg void OnClickedButtonLogout();
	afx_msg void OnBnClickedButtonUpload();
	afx_msg void OnBnClickedButtonDownload();
	afx_msg void OnBnClickedButtonRename();
	afx_msg void OnBnClickedButtonQuery();
	afx_msg void OnBnClickedButtonDelete();
	afx_msg void OnBnClickedButtonSubdir();
	afx_msg void OnBnClickedButtonParentdir();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FTPCLIENTDLG_H__2EE974A7_C302_45C3_82FB_0AEE4ACA0081__INCLUDED_)
